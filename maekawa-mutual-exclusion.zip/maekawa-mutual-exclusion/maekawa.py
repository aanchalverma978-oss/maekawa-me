"""
Maekawa's Algorithm for Distributed Mutual Exclusion  (discrete-event simulation)
-----------------------------------------------------------------------------------
* N nodes, each with a request set (quorum) of ~2*sqrt(N)-1 nodes (grid construction).
* Any two quorums intersect  ->  at most one node can hold all the votes  ->  mutual exclusion.
* Messages: REQUEST, REPLY, RELEASE  (+ FAILED, INQUIRE, YIELD to avoid deadlock).
* Requests are totally ordered by Lamport (timestamp, node_id); smaller = higher priority.
* Channels are FIFO with random delay.  Safety (<=1 node in CS) is asserted at run time.

Run:   python maekawa.py --n 9 --rounds 3 --seed 1
"""
import argparse, heapq, math, random
from collections import Counter

# ------------------------------------------------------------------ quorums
def grid_quorums(n):
    """Node i sits at (row, col) of a k x k grid. Quorum(i) = its whole row + whole column."""
    k = int(math.isqrt(n))
    if k * k != n:
        raise ValueError("N must be a perfect square (4, 9, 16, 25 ...) for the grid quorum")
    q = {}
    for i in range(n):
        r, c = divmod(i, k)
        q[i] = sorted({r * k + x for x in range(k)} | {y * k + c for y in range(k)})
    return q

def check_quorums(q):
    ids = list(q)
    assert all(i in q[i] for i in ids), "every node must be in its own quorum"
    assert all(set(q[i]) & set(q[j]) for i in ids for j in ids), "all quorums must intersect"

# ------------------------------------------------------------------ simulator
class Sim:
    def __init__(self, n, rounds, seed, cs_time=4.0):
        self.rng = random.Random(seed)
        self.n, self.rounds, self.cs_time = n, rounds, cs_time
        self.q = grid_quorums(n); check_quorums(self.q)
        self.events, self.seq, self.now = [], 0, 0.0
        self.last_delivery = {}                       # FIFO per channel
        self.msg_count = Counter()
        self.in_cs, self.cs_log, self.logs = None, [], []
        self.nodes = [Node(i, self) for i in range(n)]

    def log(self, text): self.logs.append(f"[t={self.now:7.2f}] {text}")

    def schedule(self, delay, fn, *args):
        self.seq += 1
        heapq.heappush(self.events, (self.now + delay, self.seq, fn, args))

    def send(self, src, dst, kind, **data):
        if src != dst: self.msg_count[kind] += 1      # self-messages are local, not network traffic
        delay = 0.0 if src == dst else self.rng.uniform(1.0, 3.0)
        t = max(self.now + delay, self.last_delivery.get((src, dst), 0) + 1e-6)   # keep FIFO order
        self.last_delivery[(src, dst)] = t
        self.seq += 1
        heapq.heappush(self.events, (t, self.seq, self.nodes[dst].receive, (src, kind, data)))

    def run(self):
        for nd in self.nodes:
            self.schedule(self.rng.uniform(0, 5), nd.want_cs)
        while self.events:
            self.now, _, fn, args = heapq.heappop(self.events)
            fn(*args)
        return self

    # called by nodes
    def enter(self, i):
        assert self.in_cs is None, f"SAFETY VIOLATION: node {i} entered while node {self.in_cs} in CS!"
        self.in_cs = i
        self.cs_log.append([i, self.now, None])
    def leave(self, i):
        assert self.in_cs == i
        self.in_cs = None
        self.cs_log[-1][2] = self.now


class Node:
    def __init__(self, i, sim):
        self.i, self.sim = i, sim
        self.clock = 0
        self.done = 0
        # requester state
        self.req_ts = None; self.replies = set(); self.failed = False
        self.pending_inquiries = []; self.in_cs = False
        # voter state
        self.voted = None            # (ts, id) of the request we gave our vote to
        self.queue = []              # waiting requests (heap of (ts, id))
        self.inquired = False
        self.failed_sent = set()     # requests already told FAILED by this voter
        self.t_request = 0

    # ---------------- requester side
    def want_cs(self):
        self.clock += 1
        self.req_ts = self.clock
        self.replies, self.failed, self.pending_inquiries = set(), False, []
        self.t_request = self.sim.now
        self.sim.log(f"P{self.i} REQUESTS CS  ts={self.req_ts}  quorum={self.sim.q[self.i]}")
        for k in self.sim.q[self.i]:
            self.sim.send(self.i, k, "REQUEST", ts=self.req_ts)

    def try_enter(self):
        if not self.in_cs and self.req_ts is not None and len(self.replies) == len(self.sim.q[self.i]):
            self.in_cs = True
            self.sim.enter(self.i)
            self.sim.log(f"P{self.i} >>> ENTERS CS (waited {self.sim.now - self.t_request:.1f})")
            self.sim.schedule(self.sim.cs_time, self.exit_cs)

    def exit_cs(self):
        self.sim.leave(self.i)
        self.sim.log(f"P{self.i} <<< EXITS CS, sends RELEASE")
        ts = self.req_ts
        self.in_cs, self.req_ts, self.pending_inquiries = False, None, []
        for k in self.sim.q[self.i]:
            self.sim.send(self.i, k, "RELEASE", ts=ts)
        self.done += 1
        if self.done < self.sim.rounds:
            self.sim.schedule(self.sim.rng.uniform(2, 12), self.want_cs)

    def yield_to(self, k, ts):
        self.replies.discard(k)
        self.sim.log(f"P{self.i} YIELDS vote of P{k}")
        self.sim.send(self.i, k, "YIELD", ts=ts)

    # ---------------- voter side
    def grant_next(self):
        self.inquired = False
        if self.queue:
            self.voted = heapq.heappop(self.queue)
            self.sim.send(self.i, self.voted[1], "REPLY", ts=self.voted[0])
            # Everyone still waiting now has LOWER priority than the new vote holder -> tell them (FAILED).
            # (Skipping this lets a waiting node hold other votes forever -> deadlock.)
            for w_ts, w_id in self.queue:
                if (w_ts, w_id) not in self.failed_sent:
                    self.failed_sent.add((w_ts, w_id))
                    self.sim.send(self.i, w_id, "FAILED", ts=w_ts)
        else:
            self.voted = None

    # ---------------- message dispatcher
    def receive(self, src, kind, d):
        ts = d.get("ts")
        if kind == "REQUEST":
            self.clock = max(self.clock, ts) + 1
            req = (ts, src)
            if self.voted is None:
                self.voted = req
                self.sim.send(self.i, src, "REPLY", ts=ts)
            else:
                lower_than_vote = req > self.voted
                lower_than_queue = bool(self.queue) and req > min(self.queue)
                heapq.heappush(self.queue, req)
                if lower_than_vote or lower_than_queue:
                    self.failed_sent.add(req)
                    self.sim.send(self.i, src, "FAILED", ts=ts)
                elif not self.inquired:               # higher priority than current vote -> try to recall it
                    self.inquired = True
                    self.sim.send(self.i, self.voted[1], "INQUIRE", ts=self.voted[0])

        elif kind == "RELEASE":
            if self.voted == (ts, src):
                self.grant_next()

        elif kind == "YIELD":
            if self.voted == (ts, src):
                heapq.heappush(self.queue, self.voted)    # that request goes back to waiting
                self.grant_next()

        elif kind == "REPLY":
            if ts == self.req_ts and not self.in_cs:
                self.replies.add(src); self.try_enter()

        elif kind == "FAILED":
            if ts == self.req_ts and not self.in_cs:
                self.failed = True
                for k in self.pending_inquiries: self.yield_to(k, ts)
                self.pending_inquiries = []

        elif kind == "INQUIRE":
            if ts == self.req_ts and not self.in_cs and src in self.replies:
                if self.failed: self.yield_to(src, ts)       # cannot get everything -> give vote back
                else: self.pending_inquiries.append(src)     # maybe we'll enter; decide on FAILED

# ------------------------------------------------------------------ reporting
def report(sim):
    total = sum(sim.msg_count.values()); entries = len(sim.cs_log)
    n = sim.n
    print("\n" + "=" * 62)
    print(f"Nodes: {n}   Quorum size: {len(sim.q[0])}   CS entries: {entries}")
    print("Safety check: PASSED (never more than one node in CS)")
    # verify no overlap again from the log
    spans = sorted((s, e, i) for i, s, e in sim.cs_log)
    assert all(spans[x][1] <= spans[x + 1][0] for x in range(len(spans) - 1))
    print("\nMessages by type:", dict(sim.msg_count))
    print(f"Total messages: {total}   ->  {total / entries:.1f} messages per CS entry")
    print(f"Ricart-Agrawala would need 2(N-1) = {2 * (n - 1)} per entry;  "
          f"Maekawa best case 3(K-1) = {3 * (len(sim.q[0]) - 1)}, worst ~5(K-1) = {5 * (len(sim.q[0]) - 1)}")
    print("=" * 62)

def plot(sim, path="outputs/cs_timeline.png"):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(11, 4.5))
    for i, s, e in sim.cs_log:
        ax.barh(i, e - s, left=s, color="#2563eb", edgecolor="white")
    ax.set_yticks(range(sim.n)); ax.set_yticklabels([f"P{i}" for i in range(sim.n)])
    ax.set_xlabel("Simulated time"); ax.set_title("Critical-section occupancy (no two bars overlap in time)")
    ax.grid(axis="x", alpha=.3); plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()

def scaling(path="outputs/message_complexity.png"):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    Ns, mk, ra = [4, 9, 16, 25, 36], [], []
    for n in Ns:
        s = Sim(n, 3, seed=5).run()
        mk.append(sum(s.msg_count.values()) / len(s.cs_log)); ra.append(2 * (n - 1))
    plt.figure(figsize=(7, 4.5))
    plt.plot(Ns, mk, "o-", label="Maekawa (measured)", linewidth=2)
    plt.plot(Ns, ra, "s--", label="Ricart-Agrawala 2(N-1)", linewidth=2)
    plt.xlabel("Number of nodes N"); plt.ylabel("Messages per CS entry"); plt.legend(); plt.grid(alpha=.3)
    plt.title("Message complexity"); plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    print("\nScaling (N -> msgs/CS):", {n: round(m, 1) for n, m in zip(Ns, mk)})

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=9); ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--seed", type=int, default=1); ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--scaling", action="store_true", help="also compare message complexity for several N")
    a = ap.parse_args()
    sim = Sim(a.n, a.rounds, a.seed).run()
    print("Quorums:"); [print(f"  R{i} = {sim.q[i]}") for i in range(a.n)]
    if not a.quiet: print("\n".join(sim.logs))
    report(sim); plot(sim)
    if a.scaling: scaling()
