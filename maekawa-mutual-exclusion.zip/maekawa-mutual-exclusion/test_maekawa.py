"""Run: python test_maekawa.py   (stress-tests safety + deadlock freedom over many random schedules)"""
from maekawa import Sim, grid_quorums, check_quorums

def test_quorums_intersect():
    for n in (4, 9, 16, 25, 36): check_quorums(grid_quorums(n))

def test_safety_and_liveness():
    for n in (4, 9, 16, 25):
        for seed in range(40):
            s = Sim(n, 3, seed).run()          # Sim asserts mutual exclusion on every CS entry
            assert len(s.cs_log) == n * 3, f"deadlock/starvation n={n} seed={seed}"

if __name__ == "__main__":
    test_quorums_intersect(); test_safety_and_liveness()
    print("All tests passed: quorum intersection, mutual exclusion, deadlock freedom (160 random runs).")
